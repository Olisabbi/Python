Este código realiza a manipulação de uma lista encadeada simples com um número significativo de registros. 
Os produtos são inseridos na lista em formato de fila, sendo que cada produto novo é inserido ao final da fila. 
Pouco antes de os produtos chegarem às caixas, há um leitor de código de barras que realiza a leitura e armazena em uma lista encadeada simples, 
na memória do computador, para posterior controle de estoque.
